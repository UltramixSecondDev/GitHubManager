>identifyexecutor(): [function]
>DELTA_VERSION_NUM [function]
>​gethwid(): [function]
>is_android [function]
>is_ios [function]
>is_vng [function]
>roblox_version [function]
>is_mac [function]
>version [function]
>version_num [function]
>version_hash [function]
>architecture_str [function]
>architecture [function]
>get_platform [function]



>Name< = >Xclipse<