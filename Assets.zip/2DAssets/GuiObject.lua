
[ ScreenGui:

<DisplayOrder
<Enabled
<IgnoreGuiInset
<Name
<ResetOnSpawn
<SafeAreaCompatibility
<Screeninsets


[ Frame:

>Active
>Draggable
>AnchorPoint
>BackgroundTransparency 
>BackgroundColor3
>BorderColor3
>BorderSizePixel
>ClipsDescendants
>Name
>Position 
>Size
>Visible
>ZIndex


[ ViewportFram:

>Ambient
>AnchorPoint
>AutomaticSize
>BackgroundColor3
>BackgroundTransparency
>BorderSizePixel
>BorderColor3
>ImageColor3
>ImageTransparency
>LightColor
>LightDirection
>Position
>Size
>Visible
>ZIndex


[ BillboardGui

>Active
>Adornee
>AlwaysOnTop
>Brightness
>Name
>DistanceLowerLimit
>DistanceStep
>DistanceUpperLimit
>Enabled
>ExtentsOffset
>ExtentsOffsetWorldSpace
>LightInfluence
>MaxDistance
>PlayerToHideFrom
>Size
>SizeOffset
>StudsOffset
>StudsOffsetWorldSpace


[ CanvasGroup:

>Active
>AnchorPoint
>AutomaticSize
>BackgroundColor3
>BackgroundTransparency
>BorderSizePixel
>BorderColor3
>ClipsDescendants
>Draggable
>GroupTransparency
>GroupColor3
>Name
>Size
>Position
>Size


[ ImageButton:

>BackgroundColor3
>BackgroundTransparency
>ImageTransparency
>ImageColor3
>image
>AnchorPoint
>Active
>Draggable
>ImageRectOffset
>imageRectSize
>Name
>Size
>Position
>ScaleType
>ResampleMode
>SliceCenter
>SliceScale
>Visible


[ ImageLabel:

(lo mismo que ImageButton solo agregando TileSize)


[ ScrollingFrame:

>AutomaticCanvasSize
>Active
>Draggable
>AnchorPoint
>BackgroundColor3 
>BackgroundTransparency
>BorderColor3
>BorderSizePixel
>CanvasPosition
>CanvasSize
>ClipsDescendants
>ElasticBehavior
>HorizontalScrollbarInset
>LayoutOrder
>Name
>Position
>Size
>ScrollbarThickness 
>ScrollingDirection
>ScrollingEnabled
>SizeConstraint


[ SurfaceGui:

>Active
>Adornee
>AlwaysOnTop
>Autolocalize
>Brightness
>CanvasSize
>ClipsDescendants
>Face
>LightInfluence
>MaxDistance 
>Name
>PixelsPerStud
>SizingMode
>ZIndex
>ToolPunchThroughDistance


[ TextBox:
Las mismas que Frame Solo agregando:

>Font
>FontSize
>LineHeight
>Multiline
>Name
>PlaceholderText
>PlaceHolderColor3
>Text
>TextColor3
>TextDirection
>TextScaled
>TextEditable
>TextSize
>TextStrokeColor3
>TextStrokeTransparency
>TextTransparency
>TextTruncate
>TextWrapped
>TextWrap
>TextXAlignment
>TextYAlignment
>Zindex
>Visible


[ TextButton:

(lo mismo que TextBox solo agregando RichText)


[TextLabel:

(Lo mismo que TextBox solo quitando estas propiedades 


<PlaceholderText 
<PlaceHolderColor3
<Multiline